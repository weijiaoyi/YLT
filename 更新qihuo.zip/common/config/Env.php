<?php

// 是否开启调试模式
define('YII_DEBUG', false);
// 代码执行环境，可选：'dev', 'test', 'prod'
define('YII_ENV', 'test');
