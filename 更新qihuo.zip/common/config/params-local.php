<?php
return array (
  'stocks' => 
  array (
    'data_baitang' => 'data_baitang',
    'SR1905' => 'SR1905',
    'baishatang' => 'baishatang',
    'yuanyou' => 'yuanyou',
    'hushen300' => 'hushen300',
    'zhongzheng500' => 'zhongzheng500',
    'luowengang' => 'luowengang',
  ),
);