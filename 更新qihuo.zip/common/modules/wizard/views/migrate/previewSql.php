<pre><code><?= $sql ?></code></pre>
<script>
$("code").html(hljs.highlightAuto($("code").html()).value);
</script>