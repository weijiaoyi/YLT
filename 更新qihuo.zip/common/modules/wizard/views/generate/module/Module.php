<?php
echo "<?php\n";
?>

namespace <?= $namespace ?>;

use Yii;

/**
 * <?= $moduleName ?> 模块
 */
class Module extends \common\components\Module
{
}
