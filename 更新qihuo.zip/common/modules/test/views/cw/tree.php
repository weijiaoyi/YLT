<div>
关联表：
<?= $html ?>
</div>
<div>
仅当前表：
<?= $html2 ?>
</div>
<div>
多对多关系：
<?= $html3 ?>
</div>