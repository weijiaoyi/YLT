<?php

namespace common\modules\test;

use Yii;

/**
 * 测试模块
 *
 * @author ChisWill
 */
class Module extends \common\components\Module
{
}
