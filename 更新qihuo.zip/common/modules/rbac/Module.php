<?php

namespace common\modules\rbac;

use Yii;

/**
 * 权限管理模块
 *
 * @author ChisWill
 */
class Module extends \common\components\Module
{
}
