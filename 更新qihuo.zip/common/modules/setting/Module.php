<?php

namespace common\modules\setting;

use Yii;

/**
 * 公共设定模块
 *
 * @author ChisWill
 */
class Module extends \common\components\Module
{
}
