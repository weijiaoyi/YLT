<?php

namespace common\helpers;

class Json extends \yii\helpers\BaseJson
{
}
