<?php

namespace common\helpers;

class Inflector extends \yii\helpers\BaseInflector
{
}
