<?php

namespace common\components;

use Yii;

/**
 * 控制台控制器的基类
 *
 * @author ChisWill
 */
class ConsoleController extends \yii\console\Controller
{
    use \common\traits\ChisWill;
}
