<?php

namespace common\components;

/**
 * 表单模型的基类
 *
 * @author ChisWill
 */
class Model extends \yii\base\Model
{
    use \common\traits\ChisWill;
    use \common\traits\ModelTrait;
}
