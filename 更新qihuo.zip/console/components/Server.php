<?php

namespace console\components;

/**
 * 服务端基类
 * 
 * @author ChisWill
 */
class Server extends \yii\base\Component
{
    use \common\traits\ChisWill;
}
