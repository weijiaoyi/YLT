<?php

namespace frontend\components;

use Yii;
use frontend\models\User;

/**
 * frontend 控制器的基类
 */
class Controller extends \common\components\WebController
{
    public function init()
    {
        parent::init();

    }
    
 
}

        