<?php
// 后台作为一个子模块，嵌入项目内，缩略命名空间长度
Yii::setAlias('admin', dirname(__DIR__) . '/modules/admin');
