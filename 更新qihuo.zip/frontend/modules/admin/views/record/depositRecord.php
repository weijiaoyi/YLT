<?php use common\helpers\Html; ?>

<?= $html ?>

<p class="cl pd-5 mt-20">
    <span>当前总共充值了<span class="count" style="color:#E31;"><?= $count ?></span>元</span>
</p>