<?php
/**
 * Created by PhpStorm.
 * User: 10
 * Date: 2019/5/7
 * Time: 11:03
 */

namespace frontend\models;


use yii\db\ActiveRecord;

class OrderCharge extends  ActiveRecord
{
    public function rules()
    {


    }
}