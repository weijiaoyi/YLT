<?php
/**
 * Created by PhpStorm.
 * User: 10
 * Date: 2019/7/2
 * Time: 17:55
 */

namespace admin\models;

use yii\db\ActiveRecord;


class UserInvitationCode extends ActiveRecord
{

}